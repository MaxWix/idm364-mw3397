<script>
    import Header from '$lib/Header.svelte';
</script>

<Header />
<slot />

<style>
  
</style>