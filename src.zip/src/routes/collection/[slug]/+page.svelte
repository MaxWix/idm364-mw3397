<!-- src/routes/[slug]/+page.svelte -->
<script lang="js">
   import '$lib/styles.css';
   import { page } from '$app/stores';
    import FeaturedItems from '$lib/featuredItems.svelte';
    import Plant from '$lib/plantSingle.svelte';
    import OrderOptions from '$lib/orderOptions.svelte';
    import Paragraphs from '$lib/singlePageParagraph.svelte';

  /**
   * @typedef {Object} Plant
   * @property {string} name - The name of the team.
   * @property {string} subtitle - The city of the team.
   * @property {intiger} price - The mascot of the team.
   * @property {string} description - The record of the team.
   */

  /**
   * @typedef {Object} Data
   * @property {Plant[]} plants - The team data.
   */

  /** @type {Data} */
  export let data;

   let plant = data.plants;

  $: {
    const { slug } = $page.params;
    plant = data.plants.find((plant) => plant.slug === slug);
  }
</script>

{#if plant}
  <div class="imageHeaderPriceCon">
    <div class="imageCon">
        <Plant images={plant.images} initialImgId={1}/>
    </div>
    <!-- Remainder of your layout -->
    <div class="priceCon">
        <h3 class="plantConTitle plantConText">{plant.name}</h3>
        <h4 class="plantDollars plantConText">${plant.price}</h4>
      <div class="orderOptions">  
        <OrderOptions optionTitle='Color' options={plant.colorOptions}/>
        <OrderOptions optionTitle='Pot Style' options={plant.potStyle} />
        <OrderOptions optionTitle='Plant size' options={plant.sizeOptions} />
      </div>
  

    <button clasd='AddToCart'> 
            Add To Cart
    </button>

    <div class="guides">
            <a href="">
            <p class='guideText'>Light Guide</p>
            </a>

            <a href="">
            <p class='guideText'>Size Guide</p>
            </a>
            </div>
        
    <hr> 

     <Paragraphs Paragraphs='Lorem ipsum dolor sit amet consectetur. Praesent fermentum pellentesque velit velit. Pretium venenatis ipsum viverra feugiat neque a'/>
        <Paragraphs Paragraphs='enean sagittis. Quam sapien arcu libero ligula. Faucibus cras ultrices tortor eget commodo enim.'/>
        <Paragraphs Paragraphs='Nullam elit lacus senectus massa. Ut massa cum amet.'/>
  </div> 
</div>
{:else}
  <p>No plant found</p>
{/if}

<style>
    .imageHeaderPriceCon {
        margin: 2rem 2rem;
    }

    .orderOptions{
        margin: 2rem 0;
    }

    button{
        border: 1px black solid;
        background-color:var(--light-green) ;
        padding: 0.5rem 1rem;
        border-radius: 34px;
        font-size: 20px;
        color: white;
        width:100%;
    }

    .guides{
        display: flex;
        justify-content: flex-start;
        gap: 1rem;
        margin: 1rem 0;
        color: grey;
    }

    hr {
        text-align:center;
        margin: 2rem 0rem;
    }

    h3{
        font-family: playfairRegular;
        font-weight: 400;
    }

    h4{
        font-family: "encodeSansReg";
        font-weight: 400;
    }

    .plantConText {
        margin: 0.5rem 0 0;
    }

    @media screen and (min-width: 535px) {
        .imageHeaderPriceCon{
            display: grid;
            grid-template-columns: 1fr 1fr;
            column-gap: 4rem;
            margin: 2rem auto;
            padding: 0 2rem;
            max-width: 1000px;
        }

        .imageCon{
            grid-column: 1/2;
        }

        .priceCon{
            grid-column: 2/3;
        }

        h3{
            font-size:4rem;
        }

    }

</style>