+ <script lang="js">
   export let data;
  
 </script>

<!-- src/routes/teams/[slug]/+layout.svelte -->
<div class="layout">
  <main>
    <slot />
  </main>
</div>

<style>

</style>