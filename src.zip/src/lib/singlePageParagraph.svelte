<script>

  export let Paragraphs;
</script>

<main>
    <p>{Paragraphs}</p>
</main>

<style>
  p {
    margin-bottom: 1rem;
  }
</style>
