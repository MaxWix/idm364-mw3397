<script>
    import plant from '$lib/images/plantHolder.png'
</script>

      <a href="/collection">
        <div class="plantCon">
          <img src={plant} alt="plant" />
          <h4 class="plantConTitle plantConText">Plant A plant</h4>
          <h5 class="PlantConSub plantConText">Sub Plant A Plant</h5>
          <h5 class="plantDollars plantConText">$$$$</h5>
        </div>
      </a>

<style>
.plantConText {
  margin: 0.5rem 0 0;
}
</style>